package br.unipar.programacaointernet.clinica.repository;

import br.unipar.programacaointernet.clinica.model.Medico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicoRepository extends JpaRepository<Medico, Integer> {
}
