package br.unipar.programacaointernet.clinica.repository;

import br.unipar.programacaointernet.clinica.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Paciente, Integer> {


}
