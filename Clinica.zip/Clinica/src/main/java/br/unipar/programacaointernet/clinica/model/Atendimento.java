package br.unipar.programacaointernet.clinica.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
public class Atendimento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private LocalDateTime dataHora;

    private String anamnese;

    @ManyToOne
    @JoinColumn(name = "fk_medico_id", nullable = false)
    private Medico medico;

    @ManyToOne
    @JoinColumn(name = "fk_paciente_id", nullable = false)
    private Paciente paciente;
}
