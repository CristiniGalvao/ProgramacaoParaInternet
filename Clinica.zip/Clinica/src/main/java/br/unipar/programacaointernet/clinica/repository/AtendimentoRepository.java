package br.unipar.programacaointernet.clinica.repository;

import br.unipar.programacaointernet.clinica.model.Atendimento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AtendimentoRepository extends JpaRepository<Atendimento, Integer> {
}
