package br.unipar.programacaointernet.clinica.controller;

import br.unipar.programacaointernet.clinica.model.Atendimento;
import br.unipar.programacaointernet.clinica.service.AtendimentoService;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class AtendimentoWebController {

    private final AtendimentoService atendimentoService;

    public AtendimentoWebController(AtendimentoService atendimentoService) {
        this.atendimentoService = atendimentoService;
    }

    @GetMapping(path = "/atendimentos")
    public String getAllAtendimento(Model model) {
        List<Atendimento> atendimentos = atendimentoService.getAll();
        model.addAttribute("atendimentos",atendimentos);
        return "atendimentos";
    }

    @PostMapping(path = "/atendimentos/save")
    public String saveAtendimento(@ModelAttribute Atendimento atendimento) {
        atendimentoService.save(atendimento);
        return "redirect:/atendimentos";
    }
}
